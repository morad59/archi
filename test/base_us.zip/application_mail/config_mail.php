<?php

return [
    'server_smtp_mail' => '{imap.ionos.fr:993/imap/ssl}INBOX',
    'id_mail' => 'contact@appliops.fr',
    'api_key_mail' => 'Encule1985&&a&'
];

?>

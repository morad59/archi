<?php
class Mailbox{

   public $config_file;
   public $user_id;
   public $user_pw;
   public $mailbox;
   public $attachmentfolder;
   public $folders;
   public $headers;
   public $nbmail;


    function __construct(string $mailbox=null, string $user=null, string $passwd=null) {}









}
?>

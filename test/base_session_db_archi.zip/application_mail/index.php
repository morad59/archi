<?php

session_start([
    'cookie_lifetime' => 86400,
]);

/*gestion sessions ok*/
/*gestion dbSessions ok*/
/*gestion configIdPwSessions db1 ok hashTable2*/
/*gestion languages ok*/

/*
define('CLASS_DIR', 'class/front_class');
set_include_path(get_include_path().PATH_SEPARATOR.CLASS_DIR);
spl_autoload_extensions('.class.php');
spl_autoload_register();
*/

require 'vendor/autoload.php';
$f3 = \Base::instance();

$languages=\ISO::instance()->languages();

$geo = \Web\Geo::instance();
$global_lang = strtolower($geo->location()["country_code"]);
$f3->set('lang',$global_lang );

$weather_key = '61ae8e8fd8d0f8f956a9600fff9b808f';
//echo( file_get_contents( 'http://api.openweathermap.org/data/2.5/weather?q='.strtolower($geo->location()["city"]).'&appid='.$weather_key));
/*********************************************************SESSION HANDLER**********************************************************/
$config = require __DIR__.'/config.php';

$pw_db = $config['pw_db'];
$id_db = $config['id_db'];
$na_db = $config['na_db'];


class obj implements Serializable {
    private $data;
    public function __construct($datas) {
       $this->data = $datas;
    }
    public function serialize() {
       return serialize($this->data);
    }
    public function unserialize($data) {
       $this->data = unserialize($data);
    }
    public function getData() {
       return (is_object($this->data))?$this->getData():$this->data;
     }
}

function translate($term){
        global $id_db, $pw_db, $na_db, $global_lang;
        $db = new mysqli("localhost", $id_db, $pw_db, $na_db);
        $rows=$db->query('SELECT `'.$global_lang.'` FROM `translate` WHERE `id` = '.$term );
        $row = $rows->fetch_assoc();
        return $row[$global_lang];
}

function getUserIpAddr(){
   if(!empty($_SERVER['HTTP_CLIENT_IP'])){
       $ip = $_SERVER['HTTP_CLIENT_IP'];
   }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
       $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
   }else{
       $ip = $_SERVER['REMOTE_ADDR'];
   }
   return $ip;
}
$db = new mysqli("localhost", $id_db, $pw_db, $na_db);
$rows=$db->query("SELECT * FROM `sessions` WHERE `data` != '' AND `ip` LIKE '".getUserIpAddr()."' ORDER BY `stamp` DESC");
$row = $rows->fetch_assoc();

if ( isset($row) ){

    global $id_db, $pw_db, $na_db;
    $db = new mysqli("localhost", $id_db, $pw_db, $na_db);
    $id_session = session_id();
 
    //charger les datas de la session sauvegarde
    $f3->set('SESSION.visitor',base64_encode( time() ) );
    $f3->set('SESSION.csrf',substr($row["data"], strrpos($row["data"], ":")+3, -2) );
    $newobj = new obj($_SESSION["payload"]);
    $newobj = unserialize($newobj->getData());
   
    if ($newobj == false){
       $duree = time()+3600*24*7;
       $options = ["expires" => $duree, "path" => "/appliops_user_cookies/", "domain" => "appliops.com", "secure" => "TRUE", "httponly" => "TRUE", "samesite" => "Strict"];
       $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
       //$_SESSION["sss"] = (setcookie("appliops_user_cookie","a_u_c", $duree, "/appliops_user_cookies/", $domain, TRUE, TRUE))?$ser:"aucune datas";
       $_SESSION["visitor"] = base64_encode( $id_session );
 
       $myCsrf = bin2hex(openssl_random_pseudo_bytes(24));
       $id_session = session_id();
       $sess_datas["csrf"] = $myCsrf;
       $sess_datas["logged"] = false;
       $sess_datas["user_agent"] = $_SERVER['HTTP_USER_AGENT'];
       $sess_datas["id_ip_user_agent"] = base64_encode($_SERVER['HTTP_USER_AGENT']);
       $sess_datas["id_session"] = $id_session;
       $obj = new obj($sess_datas);
       $ser = serialize($obj);
       $_SESSION["payload"] = $ser;
       $newobj = new obj($datas_received_process);
       $ser = serialize($obj);
     
       if ( $datas_received_process["user_agent"] != $_SERVER['HTTP_USER_AGENT'] ){
 $rows=$db->query("INSERT INTO `sessions` (`session_id`,`data`,`ip`,`agent`,`stamp`) VALUES ('".$id_session."','".$ser."','".getUserIpAddr()."','".$_SERVER['HTTP_USER_AGENT']."','".time()."');");
       }
    }
    $cookie_file_save = $id_session;
    $datas_received_process = unserialize($datas_received);
    $drp = $datas_received_process;
    if ($_SESSION["csrf"]){

    }else{
       $myCsrf = bin2hex(openssl_random_pseudo_bytes(24));
       $drp["csrf"] = $_SESSION["csrf"];
       $_SESSION["csrf"] = $myCsrf;;
    }
    $obj = new obj($datas_received_process);
    $ser = serialize($obj);
    if ( gettype($datas_received_process) == "object" ){
        if ( $datas_received_process->getData()['user_agent'] != $_SERVER['HTTP_USER_AGENT'] ){
  $rows=$db->query("INSERT INTO `sessions` (`session_id`,`data`,`ip`,`agent`,`stamp`) VALUES ('".$id_session."','".$ser."','".getUserIpAddr()."','".$_SERVER['HTTP_USER_AGENT']."','".time()."');");
        }
    }else{
        if ( $datas_received_process["user_agent"] != $_SERVER['HTTP_USER_AGENT'] ){
  $rows=$db->query("INSERT INTO `sessions` (`session_id`,`data`,`ip`,`agent`,`stamp`) VALUES ('".$id_session."','".$ser."','".getUserIpAddr()."','".$_SERVER['HTTP_USER_AGENT']."','".time()."');");
        }
    }
 
    $cookie_file_save = substr( $_SESSION["csrf"], 0, strpos($_SESSION["csrf"], "\";") );
    $cookie_file_save = substr( $_SESSION["csrf"], 0, 32 );
    $cookie_file_save = $cookie_file_save."_".$newobj->getData()["id_ip_user_agent"];
    file_put_contents("./appliops_user_cookies/".$cookie_file_save.".txt", $ser );
}else{
    ini_set('session.use_strict_mode', 1);
    session_start();
    global $id_db, $pw_db, $na_db;
    $db = new mysqli("localhost", $id_db, $pw_db, $na_db);
    $myCsrf = bin2hex(openssl_random_pseudo_bytes(24));
    $id_session = session_id();
    $sess_datas["csrf"] = $myCsrf;
    $sess_datas["logged"] = false;
    $sess_datas["user_agent"] = $_SERVER['HTTP_USER_AGENT'];
    $sess_datas["id_ip_user_agent"] = base64_encode($_SERVER['HTTP_USER_AGENT']);
    $sess_datas["id_session"] = $id_session;
    $obj = new obj($sess_datas);
    $ser = serialize($obj);
    $_SESSION["payload"] = $ser;
    
    $rows=$db->query("INSERT INTO `sessions` (`session_id`, `data`, `ip`, `agent`, `stamp`) VALUES ('".$id_session."','".$ser."','".getUserIpAddr()."','".$_SERVER['HTTP_USER_AGENT']."','".time()."' ); ");
 
    $duree = time()+3600*24*7;
    $options = ["expires" => $duree, "path" => "/appliops_user_cookies/", "domain" => "appliops.com", "secure" => "TRUE", "httponly" => "TRUE", "samesite" => "Strict"];
    $domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false;
    //$_SESSION["sss"] = (setcookie("appliops_user_cookie","a_u_c", $duree, "/appliops_user_cookies/", $domain, TRUE, TRUE))?$ser:"aucune datas";
    $_SESSION["visitor"] = base64_encode( $id_session );
 
    $cookie_file_save = $id_session;
    file_put_contents("./appliops_user_cookies/".$cookie_file_save.".txt", $ser );
}

/*********************************************************SESSION HANDLER**********************************************************/

$f3->route('GET /',
    function($f3, $params) {
        $params[1] = $_SESSION;
        //echo 'Hello, world!';
        //$_SESSION['prenom'] = 'Pierre';
        $f3->set('title',translate(6));
        $f3->set('trusted_space',translate(1));
        $f3->set('id_w',translate(2));
        $f3->set('pw_w',translate(3));
        $f3->set('id_pl_w',translate(4));
        $f3->set('pw_pl_w',translate(3));
        $f3->set('login_w',translate(5));
        if ($_SESSION["app_error"] != ''){
           echo $_SESSION["app_error"]; 
           unset( $_SESSION["app_error"] ); 
        }
        echo View::instance()->render('ui/layout-login.htm');
    }
);

$f3->route('GET|POST /main',
    function($f3, $params) {
       global $id_db, $pw_db, $na_db;
       $params[1] = $_SESSION;
       $id_ok = false;
       $pw_ok = false;
       $login_atempt = false;

       if (isset($_POST["username"])&&$_POST["username"]!=""){
          $id_ok = true;
       }
       if (isset($_POST["password"])&&$_POST["password"]!=""){
          $pw_ok = true;
       }
       if ($id_ok && $pw_ok || $_SESSION["logged_in"]){
          $login_atempt = true;

          $db = new mysqli("localhost", $id_db, $pw_db, $na_db);
          $rows=$db->query("SELECT `id_utilisateur`, `ville` FROM `utilisateurs` WHERE `pw` = SHA1('".base64_encode($_POST["password"])."');" );
          $row = $rows->fetch_assoc();

          $_SESSION["logged_in"] = true;
          $_SESSION["id_utilisateur"] = $row["id_utilisateur"];
          $_SESSION["ville"] = $row["ville"];
       }else{
          //credentials not recognized redirect to log page
          $_SESSION["app_error"] = translate(7);
          $f3->reroute('/');
       }

       $home_visible="visible";
       $f3->set('home_visible',$home_visible);
       $f3->set('id_utilisateur',$_SESSION["id_utilisateur"]);
       $f3->set('ville',$_SESSION["ville"]);


       $obj = new obj($_SESSION);
       $ser = serialize($obj);
       $_SESSION["payload"] = $ser;
       $id_session = session_id();
       $rows=$db->query("INSERT INTO `sessions` (`session_id`,`data`,`ip`,`agent`, `stamp`) VALUES ('".$id_session."','".$ser."','".getUserIpAddr()."','".$_SERVER['HTTP_USER_AGENT']."','".time()."' ); ");
 
      echo View::instance()->render('ui/layout-main.htm');
    }
);



$f3->run();



?>

<?php

return [
    'pw_db' => 'Encule1985&&a&',
    'id_db' => 'phpmyadmin',
    'na_db' => 'appliops_mssante_appliops',
];

<?php
$config = require __DIR__.'/../config.php';

$pw_db = $config['pw_db'];
$id_db = $config['id_db'];
$na_db = $config['na_db'];
$db = new mysqli("localhost", $id_db, $pw_db, $na_db);

$new_user = "morad.derouich@mssante.appliops.fr";
$new_user_pw = "Mdhdf2021";
$new_user_ville = "Hazebrouck";
$rows=$db->query("INSERT INTO `utilisateurs` (`id_utilisateur`,`pw`,`ville`) VALUES ('".$new_user."',SHA1('".base64_encode($new_user_pw)."'),'".$new_user_ville."');");

var_dump($rows);










?>
